package Rohit_Yalavarthi_teladoc_challenge.Rohit_Yalavarthi_teladoc_challenge;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
