package PageObjectsNewUser;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class NewUser {
	WebDriver driver;
	public NewUser(WebDriver rdriver){
		
		driver=rdriver;
		PageFactory.initElements(rdriver, this);
}

@FindBy(xpath = "//button[@class='btn btn-link pull-right']")
WebElement newuser;

@FindBy(name = "FirstName")	
WebElement fName;


@FindBy(name = "LastName")	
WebElement lName;


@FindBy(name = "UserName")	
WebElement uName;


@FindBy(name = "Password")	
WebElement pwd;

@FindBy(xpath = "//input[@value = '15']")
WebElement aaa;

@FindBy(name = "Email")
WebElement email;

@FindBy(name = "Mobilephone")
WebElement phone;

@FindBy(xpath = ("//button[@class='btn btn-success']"))
WebElement save;

public void newuser() {
	newuser.click();
}
public void setfname(String fname) {
	fName.sendKeys(fname);
}
public void setlname(String lname) {
	lName.sendKeys(lname);
}
public void setuname(String uname) {
	uName.sendKeys(uname);
}
public void setpassword(String Pwd) {
	pwd.sendKeys(Pwd);
}
public void type() {
	aaa.click();
}
public void Ddown() {
	Select role = new Select(driver.findElement(By.name("RoleId")));
	role.selectByVisibleText("Customer");
}
public void setemail(String Email) {
	email.sendKeys(Email);
}
public void setphone(String Phone) {
	phone.sendKeys(Phone);
}
public void setsave() {
	save.click();
}
}