package Rohit_Yalavarthi_teladoc_challenge.Rohit_Yalavarthi_teladoc_challenge;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;


public class baseclass {
	
	public static WebDriver driver;
	public String baseURL ="https://www.way2automation.com/angularjs-protractor/webtables/";
	public String fName = "Rohit";
	public String lName = "Yalavarthi";
	public String uName = "TestUser";
	public String pwd = "Test@123";
	public String email = "test@test.com";
	public String phone = "1234567890";
	
	@BeforeClass
	public void setup() {
		System.setProperty("webdriver.gecko.driver","/Users/u787175/Downloads/geckodriver" );
		driver = new FirefoxDriver();
	}
	
//	@AfterClass
//	public void closepage() {
		
//		driver.quit();
//	}
}
