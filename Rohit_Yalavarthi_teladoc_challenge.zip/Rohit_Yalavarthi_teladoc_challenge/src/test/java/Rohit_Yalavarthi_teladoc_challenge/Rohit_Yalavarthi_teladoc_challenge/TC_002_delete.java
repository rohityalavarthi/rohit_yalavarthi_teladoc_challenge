package Rohit_Yalavarthi_teladoc_challenge.Rohit_Yalavarthi_teladoc_challenge;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_002_delete extends TC_001_insert{
	
	@Test(priority=2)
	public void deleterecord() {
	WebElement mocktable = driver.findElement(By.xpath("/html/body/table/tbody"));
	List < WebElement > rows_table = mocktable.findElements(By.tagName("tr"));
	int rows_count = rows_table.size();
	for (int row = 0; row < rows_count; row++) {
	    List < WebElement > Columns_row = rows_table.get(row).findElements(By.tagName("td"));  
	        String celtext = Columns_row.get(2).getText();
	        if(celtext.equals("novak"))  	        
	        {
	        	Columns_row.get(10).findElement(By.className("btn-link")).click();
	        	try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        	driver.findElement(By.className("btn-primary")).click();
	        	Assert.assertEquals(celtext, "novak");
	        	break;
	        	
	        }
	        	
	           
	}
}


}
