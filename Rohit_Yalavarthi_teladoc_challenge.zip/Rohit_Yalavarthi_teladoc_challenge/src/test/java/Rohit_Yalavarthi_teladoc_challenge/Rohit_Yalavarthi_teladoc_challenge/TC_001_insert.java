package Rohit_Yalavarthi_teladoc_challenge.Rohit_Yalavarthi_teladoc_challenge;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import PageObjectsNewUser.NewUser;

public class TC_001_insert extends baseclass {

	
	@Test
	public void insertrecord() {
		
/*	
		
		WebElement mocktable = driver.findElement(By.xpath("/html/body/table/tbody"));
		List < WebElement > rows_table = mocktable.findElements(By.tagName("tr"));
		int rows_count = rows_table.size();
		for (int row = 0; row < rows_count; row++) {
    	    List < WebElement > Columns_row = rows_table.get(row).findElements(By.tagName("td"));  
    	        String celtext = Columns_row.get(2).getText();
    	        if(celtext.equals("TestUser"))  	        
    	        	System.out.println("Record inserted successfully");
    	        	      
		}*/
		
		driver.get(baseURL);
		 NewUser login = new NewUser(driver);
		 login.newuser();
		 login.setfname(fName);
		 login.setlname(lName);
		 login.setuname(uName);
		 login.setpassword(pwd);
		 login.type();
		 login.Ddown();
		 login.setemail(email);
		 login.setphone(phone);
		 login.setsave();
		 WebElement mocktable = driver.findElement(By.xpath("/html/body/table/tbody"));
			List < WebElement > rows_table = mocktable.findElements(By.tagName("tr"));
			int rows_count = rows_table.size();
			for (int row = 0; row < rows_count; row++) {
	    	    List < WebElement > Columns_row = rows_table.get(row).findElements(By.tagName("td"));  
	    	        String celtext = Columns_row.get(2).getText();
	    	        if(celtext.equals("TestUser"))  	        
	    	        	Assert.assertEquals(celtext, "TestUser");
	}	
	
}
}
